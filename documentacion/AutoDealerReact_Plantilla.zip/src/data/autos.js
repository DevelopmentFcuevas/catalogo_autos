export const autos = [
  {
    id: 1,
    marca: "Toyota",
    modelo: "Hilux",
    año: 2021,
    tipo: "Pickup",
    precio: 30000,
    imagen: "https://via.placeholder.com/150"
  },
  {
    id: 2,
    marca: "Chevrolet",
    modelo: "Onix",
    año: 2022,
    tipo: "Sedán",
    precio: 18000,
    imagen: "https://via.placeholder.com/150"
  },
  {
    id: 3,
    marca: "Ford",
    modelo: "EcoSport",
    año: 2020,
    tipo: "SUV",
    precio: 22000,
    imagen: "https://via.placeholder.com/150"
  }
];
